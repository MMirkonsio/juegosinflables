import React, { useEffect, useState } from 'react'
import api from '../api.js'
import { Card, CardBody, CardHeader } from './ui/Card.jsx'

export default function UsersPanel(){
  const [users, setUsers] = useState([])
  const [form, setForm] = useState({ username:'', password:'', role:'EMPLOYEE' })
  const load = async ()=>{ const { data } = await api.get('/users'); setUsers(data) }
  useEffect(()=>{ load() },[])

  const createUser = async ()=>{
    if(!form.username || !form.password) return
    await api.post('/users', form)
    setForm({ username:'', password:'', role:'EMPLOYEE' })
    load()
  }

  const toggleActive = async (u)=>{
    await api.patch(`/users/${u.id}`, { isActive: !u.isActive })
    load()
  }

  const updateUser = async (u, changes)=>{
    await api.patch(`/users/${u.id}`, changes)
    load()
  }

  const resetPassword = async (u)=>{
    const pwd = prompt(`Nueva contraseña para ${u.username}:`)
    if(!pwd) return
    await api.patch(`/users/${u.id}`, { password: pwd })
    load()
  }

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader title="Crear usuario" />
        <CardBody>
          <div className="grid gap-3 grid-cols-1 md:grid-cols-[1fr_1fr_160px_auto]">
            <input className="px-3 py-2 rounded-xl border border-slate-300" placeholder="usuario" value={form.username} onChange={e=>setForm(s=>({...s, username:e.target.value}))} />
            <input className="px-3 py-2 rounded-xl border border-slate-300" placeholder="contraseña" type="password" value={form.password} onChange={e=>setForm(s=>({...s, password:e.target.value}))} />
            <select className="px-3 py-2 rounded-xl border border-slate-300" value={form.role} onChange={e=>setForm(s=>({...s, role:e.target.value}))}>
              <option value="EMPLOYEE">EMPLOYEE</option>
              <option value="ADMIN">ADMIN</option>
            </select>
            <button onClick={createUser} className="px-4 py-2 rounded-xl bg-brand-600 text-white hover:bg-brand-700">Crear</button>
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Usuarios" />
        <CardBody>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="text-left text-slate-600">
                  <th className="py-2 pr-4">Usuario</th>
                  <th className="py-2 pr-4">Rol</th>
                  <th className="py-2 pr-4">Activo</th>
                  <th className="py-2 pr-4">Creado</th>
                  <th className="py-2">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.id} className="border-t border-slate-200">
                    <td className="py-2 pr-4 font-medium">{u.username}</td>
                    <td className="py-2 pr-4">
                      <select className="px-2 py-1 rounded-lg border border-slate-300" value={u.role} onChange={e=>updateUser(u,{ role:e.target.value })}>
                        <option value="EMPLOYEE">EMPLOYEE</option>
                        <option value="ADMIN">ADMIN</option>
                      </select>
                    </td>
                    <td className="py-2 pr-4">
                      <button onClick={()=>toggleActive(u)} className={`px-3 py-1 rounded-lg border ${u.isActive?'border-emerald-300 text-emerald-700 bg-emerald-50 hover:bg-emerald-100':'border-slate-300 text-slate-600 bg-slate-50 hover:bg-slate-100'}`}>
                        {u.isActive? 'Activo':'Inactivo'}
                      </button>
                    </td>
                    <td className="py-2 pr-4 text-slate-500">{new Date(u.createdAt).toLocaleString()}</td>
                    <td className="py-2 flex flex-wrap gap-2">
                      <button onClick={()=>resetPassword(u)} className="px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-700">Reset clave</button>
                      <button onClick={()=>{
                        const newName = prompt('Nuevo nombre de usuario:', u.username)
                        if(newName && newName!==u.username) updateUser(u, { username: newName })
                      }} className="px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-50">Renombrar</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  )
}