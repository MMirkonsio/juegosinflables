import React, { useEffect, useMemo, useState } from 'react'
import Badge from './ui/Badge.jsx'

function format(ms){ const t=Math.max(0, Math.floor(ms/1000)); const m=String(Math.floor(t/60)).padStart(2,'0'); const s=String(t%60).padStart(2,'0'); return `${m}:${s}` }

export default function TimerCard({ session, serverOffset, onConfirm }){
  const end = new Date(session.endTime).getTime()
  const [now, setNow] = useState(Date.now() + serverOffset)
  useEffect(()=>{ const id=setInterval(()=>setNow(Date.now()+serverOffset), 500); return ()=>clearInterval(id)},[serverOffset])
  const remaining = useMemo(()=> end - now, [end, now])
  const isExpired = session.status !== 'RUNNING' || remaining <= 0

  const stateBadge = session.status === 'CONFIRMED_EXIT'
    ? <Badge color='green'>Salida confirmada</Badge>
    : session.status === 'CANCELLED'
      ? <Badge color='slate'>Cancelada</Badge>
      : isExpired ? <Badge color='amber'>Tiempo cumplido</Badge> : <Badge color='blue'>En curso</Badge>

  return (
    <div className={`card p-4 sm:p-5 ${isExpired && session.status==='EXPIRED_WAITING_CONFIRM' ? 'ring-2 ring-amber-300' : ''}`}>
      <div className="flex items-start justify-between">
        <div>
          <div className="text-lg font-semibold capitalize">{session.childName}</div>
          <div className="text-sm text-slate-500">Duración: {session.durationMinutes} min · Termina: {new Date(session.endTime).toLocaleTimeString()}</div>
        </div>
        {stateBadge}
      </div>
      <div className={`mt-3 text-4xl font-bold tracking-tight ${isExpired?'text-rose-600':'text-slate-900'}`}>{format(remaining)}</div>
      {session.status === 'EXPIRED_WAITING_CONFIRM' && (
        <button onClick={()=>onConfirm(session.id)} className="mt-4 w-full sm:w-auto px-4 py-2 rounded-xl border border-amber-300 text-amber-900 bg-amber-50 hover:bg-amber-100">Confirmar salida</button>
      )}
    </div>
  )
}
