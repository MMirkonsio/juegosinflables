import React, { useState } from 'react'
import Badge from './ui/Badge.jsx'

export default function SessionCard({ session, onEdit, onDelete, isAdmin }){
  const [editing, setEditing] = useState(false)
  const [childName, setChildName] = useState(session.childName)
  const [durationMinutes, setDurationMinutes] = useState(session.durationMinutes)

  return (
    <div className="card p-4 sm:p-5 space-y-3">
      {!editing ? (
        <>
          <div className="flex items-center justify-between">
            <div className="font-semibold text-lg">{session.childName}</div>
            <Badge color={session.status==='CANCELLED'?'slate':'green'}>{session.status}</Badge>
          </div>
          <div className="text-sm text-slate-500">Duración: {session.durationMinutes} min</div>
          {isAdmin && (
            <div className="flex gap-2">
              <button onClick={()=>setEditing(true)} className="px-3 py-2 rounded-xl bg-slate-900 text-white hover:bg-slate-700">Editar</button>
              <button onClick={()=>onDelete(session.id)} className="px-3 py-2 rounded-xl border border-rose-300 text-rose-700 bg-rose-50 hover:bg-rose-100">Cancelar</button>
            </div>
          )}
        </>
      ) : (
        <div className="space-y-3">
          <input className="w-full px-3 py-2 rounded-xl border border-slate-300" value={childName} onChange={e=>setChildName(e.target.value)} />
          <input type="number" min="1" className="w-full px-3 py-2 rounded-xl border border-slate-300" value={durationMinutes} onChange={e=>setDurationMinutes(parseInt(e.target.value||'0',10))} />
          <div className="flex gap-2">
            <button onClick={()=>{ onEdit(session.id, { childName, durationMinutes }); setEditing(false) }} className="px-3 py-2 rounded-xl bg-brand-600 text-white hover:bg-brand-700">Guardar</button>
            <button onClick={()=>setEditing(false)} className="px-3 py-2 rounded-xl border border-slate-300 hover:bg-slate-50">Cancelar</button>
          </div>
        </div>
      )}
    </div>
  )
}