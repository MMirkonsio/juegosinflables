import { useEffect, useRef, useState } from "react";
import api from "../api.js";

export default function useServerTimeOffset() {
  const [offset, setOffset] = useState(0);
  const fetched = useRef(false);

  useEffect(() => {
    if (fetched.current) return;
    fetched.current = true;
    (async () => {
      try {
        const start = Date.now();
        const { data } = await api.get("/time");
        const end = Date.now();
        const rtt = end - start;
        const server = new Date(data.serverTime).getTime();
        const approxClientAtServerResponse = start + rtt / 2;
        setOffset(server - approxClientAtServerResponse);
      } catch (e) {
        setOffset(0);
      }
    })();
  }, []);

  return offset;
}
