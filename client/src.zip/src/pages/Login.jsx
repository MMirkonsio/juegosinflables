import React, { useState } from "react";
import api from "../api.js";
import { saveAuth } from "../auth.js";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const onSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const { data } = await api.post("/auth/login", { username, password });
      saveAuth(data.token, data.user);
      navigate("/dashboard");
    } catch (err) {
      setError(err?.response?.data?.error || "Error de autenticación");
    }
  };

  return (
    <div style={{ display: "grid", placeItems: "center", minHeight: "100vh", padding: 16 }}>
      <form onSubmit={onSubmit} style={{ display: "grid", gap: 12, minWidth: 320, border: "1px solid #ddd", padding: 24, borderRadius: 12 }}>
        <h2>Inflables — Iniciar sesión</h2>
        <input placeholder="Usuario" value={username} onChange={(e) => setUsername(e.target.value)} />
        <input placeholder="Contraseña" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <button type="submit">Entrar</button>
        {error && <div style={{ color: "crimson" }}>{error}</div>}
      </form>
    </div>
  );
}
