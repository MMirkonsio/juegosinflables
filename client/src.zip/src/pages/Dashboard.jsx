import React, { useState } from 'react'
import { getUser, logout } from '../auth.js'
import AdminPanel from '../components/AdminPanel.jsx'
import EmployeePanel from '../components/EmployeePanel.jsx'
import UsersPanel from '../components/UsersPanel.jsx'

export default function Dashboard() {
  const user = getUser()
  const [tab, setTab] = useState('sesiones')

  function Topbar() {
    return (
      <header className="border-b bg-white">
        <div className="container-page py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-brand-500 text-white grid place-items-center font-bold">IA</div>
            <div>
              <div className="text-sm text-slate-500">Inflables</div>
              <div className="h1 leading-tight">Panel</div>
            </div>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <div className="text-slate-600">Usuario: <b>{user?.username}</b> <span className="ml-1 badge bg-slate-100 text-slate-800 border border-slate-200">{user?.role}</span></div>
            <button onClick={() => { logout(); location.href='/login' }} className="px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-700">Salir</button>
          </div>
        </div>
      </header>
    )
  }

  function Tabs() {
    const isAdmin = user?.role === 'ADMIN'
    return (
      <div className="container-page mt-6">
        <div className="flex items-center gap-2 bg-white rounded-xl p-1 border border-slate-200 w-fit">
          <button onClick={() => setTab('sesiones')} className={`px-4 py-2 rounded-lg text-sm ${tab==='sesiones'?'bg-brand-500 text-white':'text-slate-700 hover:bg-slate-100'}`}>Sesiones</button>
          {isAdmin && (
            <button onClick={() => setTab('usuarios')} className={`px-4 py-2 rounded-lg text-sm ${tab==='usuarios'?'bg-brand-500 text-white':'text-slate-700 hover:bg-slate-100'}`}>Usuarios</button>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-full">
      <Topbar />
      <Tabs />
      <main className="container-page py-6">
        {tab === 'sesiones' && (user?.role === 'ADMIN' ? <AdminPanel /> : <EmployeePanel />)}
        {tab === 'usuarios' && user?.role === 'ADMIN' && <UsersPanel />}
      </main>
    </div>
  )
}